let products = [];
let sales = [];
let cart = [];


// ==========================================
// STORE SETTINGS
// ==========================================

let storeSettings = {
  storeName: "My Supermarket POS",
  ownerName: "",
  phone: "",
  address: ""
};


// ==========================================
// LOAD SAVED DATA
// ==========================================

try {
  products =
    JSON.parse(localStorage.getItem("posProducts")) || [];
} catch (e) {
  products = [];
}

try {
  sales =
    JSON.parse(localStorage.getItem("posSales")) || [];
} catch (e) {
  sales = [];
}

try {
  const savedSettings =
    JSON.parse(localStorage.getItem("posStoreSettings"));

  if (savedSettings) {
    storeSettings = {
      ...storeSettings,
      ...savedSettings
    };
  }
} catch (e) {
  console.log("Store settings could not be loaded.");
}


// ==========================================
// START APP
// ==========================================

document.addEventListener("DOMContentLoaded", function () {

  // ========================================
  // ELEMENTS
  // ========================================

  const productName =
    document.getElementById("productName");

  const retailPrice =
    document.getElementById("productRetailPrice");

  const wholesalePrice =
    document.getElementById("productWholesalePrice");

  const productStock =
    document.getElementById("productStock");

  const addProductButton =
    document.getElementById("addProductButton");

  const productSearch =
    document.getElementById("productSearch");

  const saleType =
    document.getElementById("saleType");

  const customerName =
    document.getElementById("customerName");

  const customerPhone =
    document.getElementById("customerPhone");

  const amountPaid =
    document.getElementById("amountPaid");

  const completeSaleButton =
    document.getElementById("completeSaleButton");

  const customerSearch =
    document.getElementById("customerSearch");


  // STORE SETTINGS

  const storeNameInput =
    document.getElementById("storeName");

  const ownerNameInput =
    document.getElementById("ownerName");

  const storePhoneInput =
    document.getElementById("storePhone");

  const storeAddressInput =
    document.getElementById("storeAddress");

  const saveStoreButton =
    document.getElementById("saveStoreButton");


  // ========================================
  // PAYMENT METHOD
  // ========================================

  let paymentMethod =
    document.getElementById("paymentMethod");


  /*
    If the HTML doesn't already have
    paymentMethod, JavaScript creates it.
  */

  if (!paymentMethod && amountPaid) {

    const label =
      document.createElement("label");

    label.textContent =
      "Payment Method";

    label.style.display = "block";
    label.style.marginTop = "15px";
    label.style.fontWeight = "600";

    paymentMethod =
      document.createElement("select");

    paymentMethod.id =
      "paymentMethod";

    paymentMethod.innerHTML = `
      <option value="Cash">💵 Cash</option>
      <option value="ATM/Card">💳 ATM / Card</option>
      <option value="POS">🏧 POS</option>
      <option value="Transfer">🏦 Bank Transfer</option>
      <option value="Other">💰 Other</option>
    `;

    amountPaid.parentNode.insertBefore(
      label,
      amountPaid
    );

    amountPaid.parentNode.insertBefore(
      paymentMethod,
      amountPaid
    );
  }


  // ========================================
  // SAVE DATA
  // ========================================

  function saveData() {

    localStorage.setItem(
      "posProducts",
      JSON.stringify(products)
    );

    localStorage.setItem(
      "posSales",
      JSON.stringify(sales)
    );
  }


  // ========================================
  // STORE SETTINGS
  // ========================================

  function saveStoreSettings() {

    localStorage.setItem(
      "posStoreSettings",
      JSON.stringify(storeSettings)
    );
  }


  function loadStoreSettings() {

    if (!storeNameInput) return;

    storeNameInput.value =
      storeSettings.storeName || "";

    ownerNameInput.value =
      storeSettings.ownerName || "";

    storePhoneInput.value =
      storeSettings.phone || "";

    storeAddressInput.value =
      storeSettings.address || "";

    updateStoreTitle();
  }


  function updateStoreTitle() {

    const title =
      document.getElementById("appStoreName");

    if (!title) return;

    title.textContent =
      "🛒 " +
      (
        storeSettings.storeName ||
        "My Supermarket POS"
      );
  }


  if (saveStoreButton) {

    saveStoreButton.addEventListener(
      "click",
      function () {

        const name =
          storeNameInput.value.trim();

        if (name === "") {

          alert(
            "Please enter a store name."
          );

          return;
        }

        storeSettings = {

          storeName: name,

          ownerName:
            ownerNameInput.value.trim(),

          phone:
            storePhoneInput.value.trim(),

          address:
            storeAddressInput.value.trim()
        };

        saveStoreSettings();

        updateStoreTitle();

        const message =
          document.getElementById(
            "storeSaveMessage"
          );

        if (message) {

          message.textContent =
            "✅ Store information saved!";

          setTimeout(function () {

            message.textContent = "";

          }, 3000);
        }
      }
    );
  }


  // ========================================
  // ADD PRODUCT
  // ========================================

  if (addProductButton) {

    addProductButton.addEventListener(
      "click",
      function () {

        const name =
          productName.value.trim();

        const retail =
          Number(retailPrice.value);

        const wholesale =
          Number(wholesalePrice.value);

        const stock =
          Number(productStock.value);


        if (name === "") {

          alert(
            "Please enter product name."
          );

          return;
        }


        if (retail <= 0) {

          alert(
            "Please enter a valid retail price."
          );

          return;
        }


        if (wholesale <= 0) {

          alert(
            "Please enter a valid wholesale price."
          );

          return;
        }


        if (
          stock < 0 ||
          isNaN(stock)
        ) {

          alert(
            "Please enter a valid quantity."
          );

          return;
        }


        products.push({

          id:
            Date.now(),

          name:
            name,

          retailPrice:
            retail,

          wholesalePrice:
            wholesale,

          stock:
            stock
        });


        saveData();


        productName.value = "";
        retailPrice.value = "";
        wholesalePrice.value = "";
        productStock.value = "";


        showProducts();
        showSaleProducts();


        alert(
          "✅ Product added successfully!"
        );
      }
    );
  }


  // ========================================
  // SHOW PRODUCTS
  // ========================================

  function showProducts() {

    const list =
      document.getElementById("productList");

    if (!list) return;

    list.innerHTML = "";


    if (products.length === 0) {

      list.innerHTML =
        '<p class="muted">No products added yet.</p>';

    }


    products.forEach(function (product, index) {

      const stock =
        Number(product.stock);


      let stockStatus = "";

      if (stock <= 0) {

        stockStatus =
          "🔴 Out of stock";

      } else if (stock <= 5) {

        stockStatus =
          "🟠 Low stock";

      } else {

        stockStatus =
          "🟢 In stock";
      }


      list.innerHTML += `

        <div class="product">

          <strong>
            ${product.name}
          </strong>

          <br><br>

          Retail:
          ₦${Number(
            product.retailPrice
          ).toLocaleString()}

          <br>

          Wholesale:
          ₦${Number(
            product.wholesalePrice
          ).toLocaleString()}

          <br>

          Stock:
          ${stock}

          <br>

          ${stockStatus}

          <br><br>

          <button
            onclick="deleteProduct(${index})"
            style="background:#dc2626;"
          >
            🗑️ Delete
          </button>

        </div>

      `;
    });


    const productCount =
      document.getElementById("productCount");

    if (productCount) {

      productCount.textContent =
        products.length;
    }


    const lowStock =
      products.filter(function (product) {

        return Number(product.stock) <= 5;

      }).length;


    const lowStockElement =
      document.getElementById("lowStock");

    if (lowStockElement) {

      lowStockElement.textContent =
        lowStock;
    }
  }


  // ========================================
  // DELETE PRODUCT
  // ========================================

  window.deleteProduct =
    function (index) {

      const product =
        products[index];

      if (!product) return;


      const confirmDelete =
        confirm(
          `Delete "${product.name}"?`
        );


      if (!confirmDelete) return;


      products.splice(index, 1);

      saveData();

      showProducts();
      showSaleProducts();
    };


  // ========================================
  // TODAY'S SALES
  // ========================================

  function showTodaySales() {

    const today =
      new Date().toDateString();

    let total = 0;


    sales.forEach(function (sale) {

      if (
        new Date(sale.date)
          .toDateString() === today
      ) {

        total +=
          Number(sale.total);
      }
    });


    const salesTotal =
      document.getElementById("salesTotal");

    if (salesTotal) {

      salesTotal.textContent =
        "₦" +
        total.toLocaleString();
    }
  }


  // ========================================
  // PRODUCT SEARCH
  // ========================================

  if (productSearch) {

    productSearch.addEventListener(
      "input",
      function () {

        showSaleProducts();

      }
    );
  }


  if (saleType) {

    saleType.addEventListener(
      "change",
      function () {

        showSaleProducts();

      }
    );
  }


  // ========================================
  // SHOW SALE PRODUCTS
  // ========================================

  function showSaleProducts() {

    const box =
      document.getElementById("saleProducts");

    if (!box) return;


    const search =
      productSearch
        ? productSearch.value
            .trim()
            .toLowerCase()
        : "";


    box.innerHTML = "";


    const results =
      products.filter(function (product) {

        return product.name
          .toLowerCase()
          .includes(search);

      });


    if (results.length === 0) {

      box.innerHTML =
        '<p class="muted">No matching product found.</p>';

      return;
    }


    results.forEach(function (product) {

      const index =
        products.indexOf(product);


      let price;


      if (
        saleType &&
        saleType.value === "wholesale"
      ) {

        price =
          Number(product.wholesalePrice);

      } else {

        price =
          Number(product.retailPrice);
      }


      const disabled =
        Number(product.stock) <= 0
          ? "disabled"
          : "";


      box.innerHTML += `

        <div class="product">

          <strong>
            ${product.name}
          </strong>

          <br>

          Price:
          ₦${price.toLocaleString()}

          <br>

          Stock:
          ${product.stock}

          <br>

          <button
            onclick="addToCart(${index})"
            ${disabled}
          >

            ${
              Number(product.stock) <= 0
              ? "Out of Stock"
              : "🛒 Add to Cart"
            }

          </button>

        </div>

      `;
    });
  }


  // ========================================
  // ADD TO CART
  // ========================================

  window.addToCart =
    function (index) {

      const product =
        products[index];


      if (!product) return;


      if (
        Number(product.stock) <= 0
      ) {

        alert(
          "This product is out of stock."
        );

        return;
      }


      const type =
        saleType.value;


      const price =
        type === "wholesale"
          ? Number(product.wholesalePrice)
          : Number(product.retailPrice);


      const existing =
        cart.find(function (item) {

          return (
            item.index === index &&
            item.type === type
          );

        });


      if (existing) {

        if (
          existing.quantity >=
          Number(product.stock)
        ) {

          alert(
            "Not enough stock."
          );

          return;
        }


        existing.quantity++;

      } else {

        cart.push({

          index:
            index,

          name:
            product.name,

          price:
            price,

          quantity:
            1,

          type:
            type
        });
      }


      showCart();
    };


  // ========================================
  // SHOW CART
  // ========================================

  function showCart() {

    const box =
      document.getElementById("cart");

    if (!box) return;


    box.innerHTML = "";


    let total = 0;


    if (cart.length === 0) {

      box.innerHTML =
        '<p class="muted">Cart is empty.</p>';
    }


    cart.forEach(function (item, index) {

      const subtotal =
        item.price *
        item.quantity;


      total += subtotal;


      box.innerHTML += `

        <div class="product">

          <strong>
            ${item.name}
          </strong>

          <br>

          ${
            item.type === "wholesale"
            ? "Wholesale"
            : "Retail"
          }

          <br>

          ₦${item.price.toLocaleString()}
          × ${item.quantity}

          <br>

          Subtotal:
          ₦${subtotal.toLocaleString()}

          <br><br>

          <button
            onclick="decreaseQuantity(${index})"
          >
            −
          </button>

          <button
            onclick="increaseQuantity(${index})"
          >
            +
          </button>

          <button
            onclick="removeFromCart(${index})"
            style="background:#dc2626;"
          >
            Remove
          </button>

        </div>

      `;
    });


    const cartTotal =
      document.getElementById("cartTotal");


    if (cartTotal) {

      cartTotal.textContent =
        "₦" +
        total.toLocaleString();
    }


    calculateChange();
  }


  // ========================================
  // INCREASE QUANTITY
  // ========================================

  window.increaseQuantity =
    function (index) {

      const item =
        cart[index];

      if (!item) return;


      const product =
        products[item.index];


      if (
        item.quantity >=
        Number(product.stock)
      ) {

        alert(
          "Not enough stock."
        );

        return;
      }


      item.quantity++;

      showCart();
    };


  // ========================================
  // DECREASE QUANTITY
  // ========================================

  window.decreaseQuantity =
    function (index) {

      if (
        cart[index].quantity > 1
      ) {

        cart[index].quantity--;

      } else {

        cart.splice(index, 1);
      }


      showCart();
    };


  // ========================================
  // REMOVE FROM CART
  // ========================================

  window.removeFromCart =
    function (index) {

      cart.splice(index, 1);

      showCart();
    };


  // ========================================
  // CALCULATE TOTAL
  // ========================================

  function getCartTotal() {

    let total = 0;


    cart.forEach(function (item) {

      total +=
        item.price *
        item.quantity;

    });


    return total;
  }


  // ========================================
  // CALCULATE CHANGE
  // ========================================

  function calculateChange() {

    const changeDisplay =
      document.getElementById(
        "changeDisplay"
      );


    if (!changeDisplay) return;


    const total =
      getCartTotal();


    const paid =
      amountPaid
        ? Number(amountPaid.value)
        : 0;


    if (
      paid <= 0 ||
      total <= 0
    ) {

      changeDisplay.innerHTML = "";

      return;
    }


    if (paid < total) {

      const remaining =
        total - paid;


      changeDisplay.innerHTML = `

        <strong style="color:#dc2626;">

          Amount remaining:
          ₦${remaining.toLocaleString()}

        </strong>

      `;

    } else {

      const change =
        paid - total;


      changeDisplay.innerHTML = `

        <strong style="color:#16a34a;">

          Change:
          ₦${change.toLocaleString()}

        </strong>

      `;
    }
  }


  if (amountPaid) {

    amountPaid.addEventListener(
      "input",
      calculateChange
    );
  }


  // ========================================
  // COMPLETE SALE
  // ========================================

  if (completeSaleButton) {

    completeSaleButton.addEventListener(
      "click",
      function () {

        if (cart.length === 0) {

          alert(
            "Your cart is empty."
          );

          return;
        }


        const name =
          customerName.value.trim();


        const phone =
          customerPhone.value.trim();


        if (name === "") {

          alert(
            "Please enter customer name."
          );

          return;
        }


        if (phone === "") {

          alert(
            "Please enter customer phone number."
          );

          return;
        }


        const total =
          getCartTotal();


        const paid =
          Number(amountPaid.value);


        if (isNaN(paid) || paid < total) {

          alert(
            "Amount paid is not enough.\n\n" +
            "Total: ₦" +
            total.toLocaleString()
          );

          return;
        }


        const change =
          paid - total;


        const selectedPaymentMethod =
          paymentMethod
            ? paymentMethod.value
            : "Cash";


        // ==================================
        // REDUCE STOCK
        // ==================================

        cart.forEach(function (item) {

          products[item.index].stock -=
            item.quantity;

        });


        // ==================================
        // SAVE SALE
        // ==================================

        const sale = {

          id:
            Date.now(),

          date:
            new Date().toISOString(),

          customerName:
            name,

          customerPhone:
            phone,

          paymentMethod:
            selectedPaymentMethod,

          items:
            cart.map(function (item) {

              return {

                name:
                  item.name,

                price:
                  item.price,

                quantity:
                  item.quantity,

                type:
                  item.type
              };

            }),

          total:
            total,

          paid:
            paid,

          change:
            change
        };


        sales.unshift(sale);


        saveData();


        // ==================================
        // SHOW CHANGE
        // ==================================

        const changeDisplay =
          document.getElementById(
            "changeDisplay"
          );


        if (changeDisplay) {

          changeDisplay.innerHTML = `

            <strong style="color:#16a34a;">

              Change:
              ₦${change.toLocaleString()}

            </strong>

          `;
        }


        // ==================================
        // RECEIPT ITEMS
        // ==================================

        let receiptItems = "";


        cart.forEach(function (item) {

          const subtotal =
            item.price *
            item.quantity;


          receiptItems += `

            <div class="receipt-line">

              <span>
                ${item.name}
                × ${item.quantity}
              </span>

              <span>
                ₦${subtotal.toLocaleString()}
              </span>

            </div>

          `;
        });


        // ==================================
        // RECEIPT
        // ==================================

        const receipt =
          document.getElementById(
            "receipt"
          );


        if (receipt) {

          receipt.innerHTML = `

            <h2>
              ${storeSettings.storeName}
            </h2>

            ${
              storeSettings.ownerName
              ? `<p>${storeSettings.ownerName}</p>`
              : ""
            }

            ${
              storeSettings.address
              ? `<p>${storeSettings.address}</p>`
              : ""
            }

            ${
              storeSettings.phone
              ? `<p>${storeSettings.phone}</p>`
              : ""
            }

            <p>
              <strong>
                SALES RECEIPT
              </strong>
            </p>

            <hr>

            <p>
              <strong>Customer:</strong>
              ${name}
            </p>

            <p>
              <strong>Phone:</strong>
              ${phone}
            </p>

            <p>
              <strong>Payment:</strong>
              ${selectedPaymentMethod}
            </p>

            <p>
              <strong>Date:</strong>
              ${new Date().toLocaleString()}
            </p>

            <hr>

            ${receiptItems}

            <div class="receipt-total">

              <div class="receipt-line">

                <span>
                  TOTAL
                </span>

                <span>
                  ₦${total.toLocaleString()}
                </span>

              </div>

              <div class="receipt-line">

                <span>
                  PAID
                </span>

                <span>
                  ₦${paid.toLocaleString()}
                </span>

              </div>

              <div class="receipt-line">

                <span>
                  PAYMENT
                </span>

                <span>
                  ${selectedPaymentMethod}
                </span>

              </div>

              <div class="receipt-line">

                <span>
                  CHANGE
                </span>

                <span>
                  ₦${change.toLocaleString()}
                </span>

              </div>

            </div>

            <p>
              Thank you for shopping with us! ❤️
            </p>

            <button
              onclick="printReceipt()"
            >
              🖨️ Print Receipt
            </button>

          `;


          receipt.style.display =
            "block";
        }


        // ==================================
        // CLEAR CART
        // ==================================

        cart = [];

        customerName.value = "";
        customerPhone.value = "";
        amountPaid.value = "";


        if (paymentMethod) {

          paymentMethod.value =
            "Cash";
        }


        showCart();

        showProducts();

        showSaleProducts();

        showTodaySales();

        showSalesHistory();


        alert(
          "✅ Sale completed successfully!"
        );
      }
    );
  }


  // ========================================
  // CUSTOMER HISTORY
  // ========================================

  if (customerSearch) {

    customerSearch.addEventListener(
      "input",
      function () {

        showCustomerHistory();

      }
    );
  }


  function showCustomerHistory() {

    const box =
      document.getElementById(
        "customerHistory"
      );


    if (!box) return;


    const search =
      customerSearch.value
        .trim()
        .toLowerCase();


    if (search === "") {

      box.innerHTML =
        '<p class="muted">Search for a customer to see their purchase history.</p>';

      return;
    }


    const found =
      sales.filter(function (sale) {

        const name =
          String(
            sale.customerName || ""
          ).toLowerCase();


        const phone =
          String(
            sale.customerPhone || ""
          ).toLowerCase();


        return (
          name.includes(search) ||
          phone.includes(search)
        );

      });


    if (found.length === 0) {

      box.innerHTML =
        '<p class="muted">No customer history found.</p>';

      return;
    }


    let totalSpent = 0;


    found.forEach(function (sale) {

      totalSpent +=
        Number(sale.total);

    });


    let html = `

      <h3>
        👤 ${found[0].customerName}
      </h3>

      <p>
        Phone:
        ${found[0].customerPhone}
      </p>

      <p>

        <strong>
          Purchases:
        </strong>

        ${found.length}

        <br><br>

        <strong>
          Total Spent:
        </strong>

        ₦${totalSpent.toLocaleString()}

      </p>

      <hr>

    `;


    found.forEach(function (sale) {

      const date =
        new Date(sale.date);


      let items = "";


      sale.items.forEach(function (item) {

        items += `

          ${item.name}
          × ${item.quantity}
          —
          ₦${(
            item.price *
            item.quantity
          ).toLocaleString()}

          <br>

        `;
      });


      html += `

        <div class="sale-record">

          <strong>
            📅
            ${date.toLocaleDateString()}
          </strong>

          <br><br>

          ${items}

          <br>

          <strong>
            Total:
            ₦${Number(
              sale.total
            ).toLocaleString()}
          </strong>

          <br>

          Payment:
          ${sale.paymentMethod || "Cash"}

        </div>

      `;
    });


    box.innerHTML =
      html;
  }


  // ========================================
  // SALES HISTORY
  // ========================================

  function showSalesHistory() {

    const box =
      document.getElementById(
        "salesHistory"
      );


    if (!box) return;


    box.innerHTML = "";


    if (sales.length === 0) {

      box.innerHTML =
        '<p class="muted">No sales yet.</p>';

      return;
    }


    sales.forEach(function (sale) {

      const date =
        new Date(sale.date);


      let items = "";


      sale.items.forEach(function (item) {

        items +=
          item.name +
          " × " +
          item.quantity +
          "<br>";

      });


      box.innerHTML += `

        <div class="sale-record">

          <strong>

            🧾 Sale —
            ${date.toLocaleTimeString(
              [],
              {
                hour: "2-digit",
                minute: "2-digit"
              }
            )}

          </strong>

          <div class="sale-items">

            Customer:
            ${sale.customerName}

            <br>

            Phone:
            ${sale.customerPhone}

            <br>

            Payment:
            ${sale.paymentMethod || "Cash"}

            <br><br>

            ${items}

          </div>

          <div class="sale-total">

            Total:
            ₦${Number(
              sale.total
            ).toLocaleString()}

            <br>

            Paid:
            ₦${Number(
              sale.paid
            ).toLocaleString()}

            <br>

            Change:
            ₦${Number(
              sale.change
            ).toLocaleString()}

          </div>

        </div>

      `;
    });
  }


  // ========================================
  // PRINT RECEIPT
  // ========================================

  window.printReceipt =
    function () {

      const receipt =
        document.getElementById(
          "receipt"
        );


      if (!receipt) return;


      const printWindow =
        window.open(
          "",
          "_blank"
        );


      printWindow.document.write(`

        <html>

        <head>

          <title>
            Receipt
          </title>

          <style>

            body {
              font-family: Arial, sans-serif;
              padding: 20px;
              max-width: 400px;
              margin: auto;
            }

            button {
              display: none;
            }

            .receipt-line {
              display: flex;
              justify-content: space-between;
              margin: 10px 0;
            }

            .receipt-total {
              border-top: 1px dashed #777;
              padding-top: 10px;
              margin-top: 15px;
            }

            h2 {
              text-align: center;
            }

            p {
              text-align: center;
            }

          </style>

        </head>

        <body>

          ${receipt.innerHTML}

        </body>

        </html>

      `);


      printWindow.document.close();

      printWindow.focus();

      setTimeout(function () {

        printWindow.print();

      }, 300);
    };


  // ========================================
  // INITIAL DISPLAY
  // ========================================

  loadStoreSettings();

  showProducts();

  showSaleProducts();

  showCart();

  showTodaySales();

  showSalesHistory();

});
// ==========================================
// APP NAVIGATION
// ==========================================

document.addEventListener("DOMContentLoaded", function () {

  const app =
    document.querySelector(".app");

  if (!app) return;


  const sections =
    Array.from(
      document.querySelectorAll(".section")
    );


  const dashboard =
    document.querySelector(".dashboard");


  if (!dashboard || sections.length === 0) {
    return;
  }


  // ------------------------------------------
  // CREATE NAVIGATION
  // ------------------------------------------

  const nav =
    document.createElement("nav");

  nav.className =
    "app-nav";


  const navigationItems = [

    {
      name: "Home",
      icon: "⌂",
      target: "dashboard"
    },

    {
      name: "Products",
      icon: "▣",
      target: "products"
    },

    {
      name: "New Sale",
      icon: "＋",
      target: "sale"
    },

    {
      name: "Customers",
      icon: "♙",
      target: "customers"
    },

    {
      name: "Sales",
      icon: "▤",
      target: "sales"
    },

    {
      name: "Settings",
      icon: "⚙",
      target: "settings"
    }

  ];


  navigationItems.forEach(function (item) {

    const button =
      document.createElement("button");

    button.type = "button";

    button.innerHTML =
      item.icon + " " + item.name;

    button.dataset.target =
      item.target;


    button.addEventListener(
      "click",
      function () {

        showPage(item.target);

      }
    );


    nav.appendChild(button);

  });


  app.insertBefore(
    nav,
    dashboard
  );


  // ------------------------------------------
  // FIND SECTIONS
  // ------------------------------------------

  function findSection(keyword) {

    return sections.find(function (section) {

      const heading =
        section.querySelector("h2");

      if (!heading) return false;

      return heading.textContent
        .toLowerCase()
        .includes(keyword);

    });

  }


  const pageMap = {

    products:
      findSection("products"),

    sale:
      findSection("new sale"),

    customers:
      findSection("customer history"),

    sales:
      findSection("sales history"),

    settings:
      findSection("store settings")

  };


  // ------------------------------------------
  // GIVE EACH PAGE A CLASS
  // ------------------------------------------

  sections.forEach(function (section) {

    section.classList.add(
      "pos-view"
    );

  });


  dashboard.classList.add(
    "pos-view"
  );


  // ------------------------------------------
  // SHOW PAGE
  // ------------------------------------------

  function showPage(page) {

    dashboard.classList.remove(
      "active"
    );


    sections.forEach(function (section) {

      section.classList.remove(
        "active"
      );

    });


    const buttons =
      nav.querySelectorAll("button");


    buttons.forEach(function (button) {

      button.classList.remove(
        "active"
      );

    });


    if (page === "dashboard") {

      dashboard.classList.add(
        "active"
      );

    } else {

      const section =
        pageMap[page];


      if (section) {

        section.classList.add(
          "active"
        );

      }

    }


    const activeButton =
      nav.querySelector(
        `button[data-target="${page}"]`
      );


    if (activeButton) {

      activeButton.classList.add(
        "active"
      );

    }


    window.scrollTo({
      top: 0,
      behavior: "smooth"
    });

  }


  // ------------------------------------------
  // START ON HOME
  // ------------------------------------------

  showPage("dashboard");

});